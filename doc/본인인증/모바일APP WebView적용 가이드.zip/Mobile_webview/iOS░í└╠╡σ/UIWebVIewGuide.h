//
//  UIWebVIewGuide.h
//  GuideApp
//
//  Created by iOSDev on 2018. 8. 29..
//  Copyright © 2018년 Nice. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface UIWebVIewGuide : UIViewController
{
    
}
@property (nonatomic, retain) IBOutlet UIWebView *webView;
@property (nonatomic, retain) IBOutlet UIButton *prevBtn;


@end
